import Clock from "./Components/Clock/Clock";
import Login from "./Components/Login/Login";
import Navbar from "./Components/Navbar/Navbar";
import TimePicker from "./Components/DateTimePiker/TimePicker";
import DatePicker from "./Components/DateTimePiker/DatePicker";


function App() {
  return (
    <div className="bg-slate-800">
      <Navbar></Navbar>
      {/* <Clock></Clock> */}
      <DatePicker></DatePicker>
      {/* <Login></Login> */}
    </div>
  );
}

export default App;
