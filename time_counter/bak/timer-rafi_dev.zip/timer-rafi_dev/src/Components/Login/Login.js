import React from "react";

import img from "./../../Images/login_page/google-logo-9824.png";

const Login = () => {
  return (
    
    <div className=" flex flex-col  justify-center items-center  h-screen ">
      <img src={img} alt="" srcset="" className="w-24 avatar rounded-full" />
      <button className="btn mt-6  btn-outline  btn-error">Login by google</button>
    </div>
  );
};

export default Login;
