import React, { useState, useEffect } from 'react';

const TimePicker = ({setTimeData,isStartTime}) => {

  const [minute, setMinute] = useState("mm");
  const [hour, setHour] = useState("HH");
  const [ampm, setAmpm] = useState("AM/PM");
  
  const allMinutes = [];
  const allHours = [];

  const handleHour = (e) =>{
    setHour(e.target.value);
  }
  const handleMinute = (e) =>{
    setMinute(e.target.value);
  }
  const handleAmPm = (e) => {
    setAmpm(e.target.value);
  }
  useEffect(() => {
    if (minute != "mm" && hour != "HH" && ampm != "AM/PM") {
      let data =[parseInt(hour) ,parseInt(minute),ampm];
      setTimeData(data)
    }
  }, [hour,minute,ampm])
  
  
  //---reset the time input field
  useEffect(() => {
    setHour("HH");
    setMinute("mm");
    setAmpm("AM/PM");
  }, [isStartTime])
  
  
  

  //---setup minutes and hour for dropdown options
  for (let i = 0; i < 60; i++) {
    allMinutes.push(i);
  }
  for (let i = 0; i < 12; i++) {
    allHours.push(1+i);
  }
  

  return (
    <div>
      <label type="text" className="input input-bordered flex items-center h-auto input-info w-full max-w-xs">
             
             {/* ---Hours--- */}
              <div className=" dropdown dropdown-hover flex w-full p-4 justify-evenly dropdown-bottom">
                <label tabIndex="0" id="0" className="bg-blue-100 text-black rounded-md px-2 py-1">{hour}</label>
                <ul tabIndex="0" id="0" className="dropdown-content  menu p-1 pb-1 shadow bg-base-100 rounded-md w-10" onClick = {handleHour} >
                  {allHours.map((m) => (<option className=" px-2 py-1 hover:bg-slate-100 rounded-md justify-center " value={m}  >{m}</option>))}
                </ul>
             </div>
                <p className=" flex-grow-0 ">-</p>

              {/* ---minutes--- */}
                <div className=" dropdown dropdown-hover flex w-full p-4 justify-evenly dropdown-bottom">
                <label tabIndex="1" id="1" className="bg-blue-100 text-black rounded-md px-2 py-1">{minute}</label>
                <ul tabIndex="1" id="1" className="dropdown-content menu p-1 shadow bg-base-100 rounded-md w-10 " onClick = {handleMinute} >
                  <li>
                    {allMinutes.map((m) => (<option className=" px-2 py-1 hover:bg-slate-100 rounded-md justify-center " value={m} >{m}</option>))}
                  </li>
                </ul>
                </div>

                <p className=" flex-grow-0 ">-</p>


                {/* ---am or pm--- */}
                <div className=" dropdown dropdown-hover flex w-full p-4 justify-evenly dropdown-bottom">
                <label tabIndex="2" id="2" className="bg-blue-100 text-black rounded-md px-2 py-1">{ampm}</label>
                <ul tabIndex="2" id="2" className="dropdown-content menu p-1 shadow bg-base-100 rounded-md w-18" onClick={handleAmPm} >
                  <li>
                    <option value="AM" className=" px-3 py-1 hover:bg-slate-100 rounded-md w-auto" >AM</option>
                    <option value="PM" className=" px-3 py-1 hover:bg-slate-100 rounded-md w-auto" >PM</option>
                  </li>
                </ul>
              </div>
            </label>
    </div>
  );
};

export default TimePicker;