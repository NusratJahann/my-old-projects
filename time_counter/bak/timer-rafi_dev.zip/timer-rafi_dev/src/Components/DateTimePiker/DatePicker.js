
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import dayjs from "dayjs";
import TimePicker from "./TimePicker";


const DatePicker = () => {
    const [isStartTime, setIsStartTime] = useState(true) //it is used to monitor whether the time is start time or not
    const [date, setDate] = useState('DD');
    const [month, setMonth] = useState('MM');
    const [year, setYear] = useState("YYYY");
    const [timeData, setTimeData] = useState([]);
    const [startTime, setStartTime] = useState({});
    const [endTime, setEndTime] = useState({});
    

    const allDaysInMonth = [];
    const allMonths = ["January", "February","March","April", "May","June","July","August","September","October", "November","December",];
    const allYears = [];
    const hour = timeData[0];
    const minute = timeData[1];
    const ampm = timeData[2];

    const { handleSubmit,register } = useForm();
  //--making dropdown for years
    for(let i = 0;i<10; i++){
        allYears.push(i+dayjs().year());
    }
  //--making dropdown for days
    let mew = dayjs(dayjs().month(allMonths.indexOf(month))).daysInMonth();
    for (let i = 0; i < mew ; i++) {
        allDaysInMonth.push(i+1);
    }

  // --setup date time and year
    const handleSelectDate = (e) => {
        setDate(e.target.value);
    }
    const handleSelectYear = (e) => {
        setYear(e.target.value);
    }
    const handleSelectMonth = (e) => {
        setMonth(e.target.value);
    }
    // console.log(date,month,year,hour,minute,ampm)
    const handleSetButton = (data,e) => {
        e.preventDefault();
        
        /*
        start time and end time state is not working 
        so use stime and etime object
        */
        if (isStartTime == true) {
          //---here setting the start time
          const stime = {
            y:year , m: month, d:date, h:hour, min:minute, a:ampm 
          }
          setStartTime(stime);
          setIsStartTime(false);
          setDate("DD");
          setMonth("MM");
          setYear("YYYY");
          console.log("Start time -> ",startTime,stime)
        }else{
          //---here setting the end time
          const etime = {
            y:year , m: month, d:date, h:hour, min:minute, a:ampm
          }
          setIsStartTime(true);
          setEndTime(etime)
          console.log("End time => ",endTime,etime);
        }

        
      
    }

  return (
    <div className="flex justify-center h-screen items-center">
      
      
      <form onSubmit={handleSubmit(handleSetButton)}>
        
        
        <div className="card w-96 bg-base-100 shadow-xl">
          <div className="card-body">
            {isStartTime ? <h2 className="card-title">Start time</h2> : <h2 className="card-title">End time</h2>}

            <label type="text" className="input input-bordered flex items-center h-auto input-info w-full max-w-xs">
             
             {/* ---months--- */}
              <div className=" dropdown dropdown-hover flex w-full p-4 justify-evenly dropdown-bottom">
                <label tabIndex="0" id="0" className="bg-blue-100 text-black rounded-md px-2 py-1">{month}</label>
                <ul tabIndex="0" id="0" className="dropdown-content  menu p-1 pb-1 shadow bg-base-100 rounded-md w-28" onClick={ handleSelectMonth }>
                  {allMonths.map((m) => (<option className=" px-2 py-1 hover:bg-slate-100 rounded-md " value={m}  >{m}</option>))}
                </ul>
             </div>
                <p className=" flex-grow-0 ">/</p>

              {/* ---day--- */}
                <div className=" dropdown dropdown-hover flex w-full p-4 justify-evenly dropdown-bottom">
                <label tabIndex="1" id="1" className="bg-blue-100 text-black rounded-md px-2 py-1">{date}</label>
                <ul tabIndex="1" id="1" className="dropdown-content menu p-1 shadow bg-base-100 rounded-md w-10 " onClick={handleSelectDate}>
                  <li>
                    {allDaysInMonth.map((m) => (<option className=" px-2 py-1 hover:bg-slate-100 rounded-md justify-center " value={m}  >{m}</option>))}
                  </li>
                </ul>
                </div>

                <p className=" flex-grow-0 ">/</p>


                {/* ---years--- */}
                <div className=" dropdown dropdown-hover flex w-full p-4 justify-evenly dropdown-bottom">
                <label tabIndex="2" id="2" className="bg-blue-100 text-black rounded-md px-2 py-1">{year}</label>
                <ul tabIndex="2" id="2" className="dropdown-content menu p-1 shadow bg-base-100 rounded-md w-18" onClick={handleSelectYear} >
                  <li>
                    {allYears.map((m) => (<li className=" px-2 py-1 hover:bg-slate-100 rounded-md " value={m} >{m}</li>))}
                  </li>
                </ul>
              </div>
            </label>
            
            <p className=" h-2 "></p>


            <TimePicker setTimeData={setTimeData} isStartTime={isStartTime} ></TimePicker>
            <input value={month} {...register("month")} className="hidden" />
            <div className="card-actions justify-center">
              {isStartTime ? 
                <input className="btn btn-primary" onClick={handleSetButton} value="Set start time" type="submit" /> 
                : 
                <input className="btn btn-primary" onClick={handleSetButton} value="Set end time" type="submit" />
              }
            </div>
          </div>
        </div>

        {/* <input className="border-2 border-red-800" type="submit" value="Submit" /> */}
      
       
      </form>
    </div>
  );
    
};

export default DatePicker;